var lang = {
	'warning': 'Warning',
	'tips_title': 'Tips：',
	'confirm': 'Confirm',
	'confirm_title': 'Please confirm',
	'confirm_delete': 'Confirm delete？',
	'close': 'Close',
	'yes': 'Yes',
	'no': 'No',
	'open': 'Open',
	'close': 'Close',
	
	// hook lang_en_us_bbs_js.htm
	
};