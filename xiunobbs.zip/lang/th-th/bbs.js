var lang = {
	'warning': 'คำเตือน',
	'tips_title': 'เคล็ดลับ:',
	'confirm': 'ยืนยัน',
	'confirm_title': 'กรุณายืนยัน',
	'confirm_delete': 'ยืนยันการลบหรือไม่',
	'close': 'ปิด',
	'yes': 'ใช่',
	'no': 'ไม่ใช่',
	'open': 'เปิด',
	'close': 'ปิด',
	
	// hook lang_th_th_bbs_js.htm
	
};